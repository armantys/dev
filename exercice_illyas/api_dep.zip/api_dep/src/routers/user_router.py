from fastapi import APIRouter

router_user = APIRouter()

@router_user.get("/")
def get_users():
    return {"message": "Liste des utilisateurs"}

@router_user.post("/")
def create_user(user: dict):
    return {"message": "Utilisateur créé avec succès", "user": user}

