from fastapi import APIRouter, Depends
from utils.generators import generer_horodatage, generer_identifiant_unique

router_data = APIRouter()

data_storage = []

@router_data.post("/create", tags=["Gestion des données"])
def create_data(data: dict, horodatage: str = Depends(generer_horodatage), id: str = Depends(generer_identifiant_unique)):
    entry = {
        "id": id,
        "horodatage": horodatage,
        "contenu": data
    }
    data_storage.append(entry)
    return {"message": "Données créées avec succès.", "data": entry}

@router_data.get("/read", tags=["Gestion des données"])
def read_data(horodatage: str = Depends(generer_horodatage), id: str = Depends(generer_identifiant_unique)):
    return {
        "horodatage": horodatage,
        "id_session": id,
        "data": data_storage
    }
