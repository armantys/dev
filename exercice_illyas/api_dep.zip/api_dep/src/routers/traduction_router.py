from fastapi import APIRouter

router_traduction = APIRouter()

@router_traduction.get("/")
def get_translations():
    return {"message": "Liste des traductions disponibles"}

@router_traduction.post("/")
def create_translation(translation: dict):
    return {"message": "Traduction ajoutée avec succès", "translation": translation}
