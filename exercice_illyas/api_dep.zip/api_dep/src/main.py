from fastapi import FastAPI
from middlewares.process_time import add_process_time_header
from routers.user_router import router_user as user_router
from routers.traduction_router import router_traduction as traduction_router
from routers.admin_router import admin_rooter as admin_router
from routers.data_router import router_data as data_router

app = FastAPI()


# Middleware
app.middleware("http")(add_process_time_header)

# Inclure les routeurs
app.include_router(user_router, prefix="/user")
app.include_router(traduction_router, prefix="/traduction")
app.include_router(admin_router, prefix="/admin")
app.include_router(data_router, prefix="/data")
