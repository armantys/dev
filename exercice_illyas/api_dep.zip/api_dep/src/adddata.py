import requests

# URL de base de l'API
BASE_URL = "http://127.0.0.1:8000/data"

# Fonction pour ajouter des données
def ajouter_donnees(data):
    response = requests.post(f"{BASE_URL}/create", json=data)
    if response.status_code == 200:
        print("Données ajoutées :", response.json())
    else:
        print("Erreur lors de l'ajout des données :", response.status_code, response.text)

# Fonction pour lire les données
def lire_donnees():
    response = requests.get(f"{BASE_URL}/read")
    if response.status_code == 200:
        print("Données stockées :", response.json())
    else:
        print("Erreur lors de la lecture des données :", response.status_code, response.text)

# Exemple d'utilisation
if __name__ == "__main__":
    data = {"test3": "okokok"}
    ajouter_donnees(data)
    lire_donnees()
