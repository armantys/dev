from pydantic import BaseModel

class DataModel(BaseModel):
    id: str
    horodatage: str
    contenu: dict
