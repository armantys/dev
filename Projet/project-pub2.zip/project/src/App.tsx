import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider } from './contexts/ThemeContext';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Login from './pages/Login';
import WebcamPage from './pages/WebcamPage';
import ProtectedRoute from './components/ProtectedRoute';
import './index.css';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleLogin = async (email: string, password: string) => {
    // Simple mock authentication
    if (email === 'test@example.com' && password === 'password') {
      setIsLoggedIn(true);
      return { success: true };
    }
    return { success: false, error: 'Invalid credentials' };
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
  };

  return (
    <ThemeProvider>
      <Router>
        <Routes>
          <Route path="/" element={<Layout onLogout={handleLogout} isLoggedIn={isLoggedIn} />}>
            <Route index element={<Navigate to="/dashboard" replace />} />
            <Route path="/login" element={
              isLoggedIn ? <Navigate to="/dashboard" replace /> : <Login onLogin={handleLogin} />
            } />
            <Route path="/dashboard" element={
              <ProtectedRoute isLoggedIn={isLoggedIn}>
                <Dashboard />
              </ProtectedRoute>
            } />
            <Route path="/webcam" element={
              <ProtectedRoute isLoggedIn={isLoggedIn}>
                <WebcamPage />
              </ProtectedRoute>
            } />
          </Route>
        </Routes>
      </Router>
    </ThemeProvider>
  );
}

export default App;