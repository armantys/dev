import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Camera, BarChart } from 'lucide-react';
import ImageUploader from '../components/ImageUploader';
import ConfidenceGauge from '../components/ConfidenceGauge';
import { query } from '../lib/db';

interface Prediction {
  id: string;
  label: 'PUB' | 'NO PUB';
  confidence: number;
  image_url: string;
  created_at: string;
}

const Dashboard = () => {
  const [prediction, setPrediction] = useState<Prediction | null>(null);
  const [predictions, setPredictions] = useState<Prediction[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchPredictions();
  }, []);

  const fetchPredictions = async () => {
    try {
      const result = await query('SELECT * FROM predictions ORDER BY created_at DESC LIMIT 10');
      setPredictions(result.rows);
    } catch (err) {
      console.error('Error fetching predictions:', err);
      setError('Failed to load predictions');
    }
  };

  const handleImageSelect = async (file: File) => {
    setIsLoading(true);
    setError(null);
    
    try {
      const formData = new FormData();
      formData.append('image', file);

      const response = await fetch('http://your-fastapi-url/predict/', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Failed to analyze image');
      }

      const result = await response.json();
      
      // Save prediction to database
      const reader = new FileReader();
      reader.onload = async () => {
        try {
          const newPrediction = {
            label: result.label.toUpperCase() === 'PUB' ? 'PUB' : 'NO PUB',
            confidence: result.confidence,
            image_url: reader.result as string,
          };

          await query(
            'INSERT INTO predictions (label, confidence, image_url) VALUES ($1, $2, $3) RETURNING *',
            [newPrediction.label, newPrediction.confidence, newPrediction.image_url]
          );

          await fetchPredictions();
          setPrediction(newPrediction);
          setIsLoading(false);
        } catch (err) {
          console.error('Error saving prediction:', err);
          setError('Failed to save prediction');
          setIsLoading(false);
        }
      };
      reader.readAsDataURL(file);
    } catch (err) {
      console.error('Error:', err);
      setError(err.message);
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto">
      <header className="mb-8">
        <h1 className="text-2xl font-bold text-gray-800 dark:text-white">
          Dashboard
        </h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Analysez des images pour détecter la présence de publicités
        </p>
      </header>

      {error && (
        <div className="mb-6 bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300 p-4 rounded-lg">
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upload Section */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 transition-colors duration-200">
          <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-4 flex items-center">
            <BarChart className="w-5 h-5 mr-2 text-teal-500" />
            Analyse d'image
          </h2>
          
          <div className="space-y-6">
            <ImageUploader onImageSelect={handleImageSelect} />
            
            {isLoading && (
              <div className="flex justify-center items-center py-8">
                <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-teal-500"></div>
                <span className="ml-3 text-gray-600 dark:text-gray-400">Analyse en cours...</span>
              </div>
            )}

            <div className="flex justify-between">
              <Link
                to="/webcam"
                className="inline-flex items-center px-4 py-2 border border-teal-500 text-teal-600 dark:text-teal-400 rounded-md hover:bg-teal-50 dark:hover:bg-teal-900/20 transition-colors duration-200"
              >
                <Camera className="w-4 h-4 mr-2" />
                Utiliser la webcam
              </Link>
            </div>
          </div>
        </div>

        {/* Results Section */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 transition-colors duration-200">
          <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">
            Historique des prédictions
          </h2>
          
          <div className="space-y-4">
            {predictions.map((pred) => (
              <div key={pred.id} className="border dark:border-gray-700 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className={`font-medium ${
                    pred.label === 'PUB' ? 'text-red-500' : 'text-green-500'
                  }`}>
                    {pred.label}
                  </span>
                  <span className="text-sm text-gray-500">
                    {new Date(pred.created_at).toLocaleString()}
                  </span>
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">
                  Confiance: {pred.confidence}%
                </div>
                <img 
                  src={pred.image_url} 
                  alt={`Prediction ${pred.id}`}
                  className="mt-2 rounded-md w-full object-cover h-32"
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;